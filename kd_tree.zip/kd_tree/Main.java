package kd_tree;

public class Main {
    public static void main(String[]args){
        KdTree kdTree = new KdTree() ;
    }
}
