public class Main {
    public static void main(String[]args){
        KdTree kdTree = new KdTree() ;
        System.out.println("Tor matha");
    }
}
